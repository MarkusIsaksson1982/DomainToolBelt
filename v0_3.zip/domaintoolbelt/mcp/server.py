from __future__ import annotations

from typing import Any, Mapping

from domaintoolbelt.core.types import ToolResult
from domaintoolbelt.mcp.registry import MCPRegistry


class DomainPackServer:
    def __init__(self, pack, kernel=None):
        self.pack = pack
        self.kernel = kernel
        self.registry = MCPRegistry(pack)
        self._sessions: dict[str, dict[str, Any]] = {}

    async def handle(self, payload: Mapping[str, Any]) -> Mapping[str, Any]:
        method = str(payload.get("method") or "")
        session_id = str(payload.get("session_id") or "default")

        if method == "initialize":
            return {
                "server": {
                    "name": "domaintoolbelt",
                    "version": self.pack.config.version,
                    "pack": self.pack.config.key,
                },
                "capabilities": {
                    "tools": True,
                    "workflow": self.kernel is not None,
                    "sessions": True,
                },
            }
        if method == "tools/list":
            return {
                "tools": self.registry.list_tools(),
                "pack": {
                    "key": self.pack.config.key,
                    "display_name": self.pack.config.display_name,
                },
            }
        if method == "tools/call":
            return await self._handle_tool_call(payload, session_id)
        if method in {"query/run", "answer_query"}:
            return await self._handle_query_run(payload, session_id)
        if method == "session/status":
            return self._get_session_status(session_id)
        raise ValueError(f"Unsupported method: {method}")

    async def _handle_tool_call(
        self,
        payload: Mapping[str, Any],
        session_id: str,
    ) -> Mapping[str, Any]:
        tool_name = str(payload.get("tool_name") or "")
        if not tool_name:
            return {"error": "Missing 'tool_name' field.", "session_id": session_id}

        result = await self.pack.run_tool(
            tool_name,
            str(payload.get("instruction") or ""),
            payload.get("arguments", {}),
        )
        rendered = self._serialize_result(result)
        self._sessions.setdefault(session_id, {})["last_tool_result"] = rendered
        return {"result": rendered, "session_id": session_id}

    async def _handle_query_run(
        self,
        payload: Mapping[str, Any],
        session_id: str,
    ) -> Mapping[str, Any]:
        if not self.kernel:
            return {"error": "Kernel is not attached to the MCP server.", "session_id": session_id}

        query = str(payload.get("query") or "")
        if not query:
            return {"error": "Missing 'query' field.", "session_id": session_id}

        answer = await self.kernel.run(self.pack, query)
        self._sessions[session_id] = {
            "query": query,
            "answer": answer,
            "pack": self.pack.config.key,
        }
        return {"answer": answer, "session_id": session_id}

    def _get_session_status(self, session_id: str) -> Mapping[str, Any]:
        session = self._sessions.get(session_id, {})
        return {
            "session_id": session_id,
            "found": bool(session),
            "pack": session.get("pack", self.pack.config.key),
            "query": session.get("query", ""),
            "answer": session.get("answer", ""),
        }

    @staticmethod
    def _serialize_result(result: Any) -> Any:
        if isinstance(result, ToolResult):
            return {
                "content": result.content,
                "citations": list(result.citations),
                "issues": list(result.issues),
                "metadata": dict(result.metadata),
            }
        return result
