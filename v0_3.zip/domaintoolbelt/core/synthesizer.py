from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from domaintoolbelt.core.types import WorkflowContext
from domaintoolbelt.llm.provider import LLMProvider, ProviderConfig


class DefaultSynthesizer:
    async def write_final(self, pack, ctx: WorkflowContext) -> str:
        if not ctx.completed_steps:
            return "No steps were completed."

        final_step = ctx.completed_steps[-1]
        summary = self._coerce_text(final_step.output)
        supporting = [self._coerce_text(step.output) for step in ctx.completed_steps[:-1]]

        citations: list[str] = []
        for step in ctx.completed_steps:
            citations.extend(step.citations)

        unique_citations: list[str] = []
        for citation in citations:
            if citation not in unique_citations:
                unique_citations.append(citation)

        lines = [summary]
        if supporting:
            lines.append("")
            lines.append("Supporting notes:")
            lines.extend(f"- {note}" for note in supporting if note)
        if unique_citations:
            lines.append("")
            lines.append("Citations: " + ", ".join(f"[{citation}]" for citation in unique_citations))
        return "\n".join(lines).strip()

    @staticmethod
    def _coerce_text(output: Any) -> str:
        if isinstance(output, str):
            return output
        if isinstance(output, Mapping):
            if "summary" in output:
                return str(output["summary"])
            return "; ".join(f"{key}: {value}" for key, value in output.items())
        if isinstance(output, (list, tuple)):
            return "; ".join(DefaultSynthesizer._coerce_text(item) for item in output)
        return str(output)


class LLMSynthesizer(DefaultSynthesizer):
    def __init__(self, provider: LLMProvider | None = None) -> None:
        self.provider = provider

    async def write_final(self, pack, ctx: WorkflowContext) -> str:
        if not (self.provider and callable(getattr(pack, "load_prompt", None)) and pack.config.llm.enabled):
            return await super().write_final(pack, ctx)

        evidence = self._serialize_evidence(ctx)
        prompt = pack.load_prompt(
            "write_final_answer.md",
            request=ctx.request,
            evidence=evidence,
        )
        try:
            response = await self.provider.complete(
                prompt,
                system=_load_optional_prompt(pack, "supervisor.md"),
                config=ProviderConfig(
                    model=pack.config.llm.synthesizer_model,
                    temperature=pack.config.llm.temperature,
                    max_tokens=pack.config.llm.max_tokens,
                    metadata={"pack": pack.config.key, "phase": "synthesis"},
                ),
            )
        except Exception:
            return await super().write_final(pack, ctx)

        cleaned = response.strip()
        return cleaned or await super().write_final(pack, ctx)

    def _serialize_evidence(self, ctx: WorkflowContext) -> str:
        lines: list[str] = []
        for step in ctx.completed_steps:
            lines.append(f"{step.step_id}: {step.description}")
            lines.append(self._coerce_text(step.output))
            if step.citations:
                lines.append("Citations: " + ", ".join(f"[{item}]" for item in step.citations))
            lines.append("")
        return "\n".join(lines).strip()


def _load_optional_prompt(pack: Any, filename: str) -> str | None:
    try:
        return pack.load_prompt(filename)
    except FileNotFoundError:
        return None
